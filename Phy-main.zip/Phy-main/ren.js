export class Renderer {
    constructor(engine,canvas){
        this.engine=engine;
        this.ctx=canvas.getContext('2d');
        this.canvas=canvas;
    }

    draw(){
        const ctx=this.ctx, eng=this.engine;
        ctx.fillStyle='#000'; ctx.fillRect(0,0,this.canvas.width,this.canvas.height);
        eng.links.forEach(L=>{
            const intensity=Math.min(1,Math.log10(1+L.Q*100));
            ctx.strokeStyle=`rgb(${intensity*255},${100-intensity*100},${255-intensity*255})`;
            ctx.beginPath();
            ctx.moveTo(eng.pos[L.a*2],eng.pos[L.a*2+1]);
            ctx.lineTo(eng.pos[L.b*2],eng.pos[L.b*2+1]);
            ctx.stroke();
        });
        for(let i=0;i<eng.nodesCount;i++){
            ctx.fillStyle='#fff';
            ctx.beginPath(); ctx.arc(eng.pos[i*2],eng.pos[i*2+1],3,0,7); ctx.fill();
        }
    }
}
