export class Link {
    constructor(a,b,k){
        this.a=a; this.b=b;
        this.k0=k; this.length=0; // will be set on first step
        this.D=0; this.Q=0; this.area=1.0;
        this.G_th=100; this.G_crit=600;
        this.causalState=0; // ELASTIC=0, STRESSED=1, DAMAGED=2, FRACTURED=3
    }
}
