// Engine.js
import { Link } from './Link.js';
import { advanceKinematic } from './Integrator.js';

export class Engine {
    constructor(maxNodes = 100) {
        this.pos = new Float64Array(maxNodes * 2);
        this.vel = new Float64Array(maxNodes * 2);
        this.acc = new Float64Array(maxNodes * 2);
        this.mass = new Float64Array(maxNodes).fill(1.0);
        this.invMass = new Float64Array(maxNodes).fill(1.0);
        this.nodesCount = 0;

        this.links = [];
        this.initialE = 0;
        this.cumulativeExternalWork = 0;
        this.isHalted = false;

        this.gravityVector = { x: 0, y: 0.15 };
        this.comPos = { x: 0, y: 0 };
        this.vCOM = { x: 0, y: 0 };
        this.datumCOM = { x: 0, y: 0 };
        this.maxResidual = 0;
    }

    addNode(x, y, m = 1, pinned = false) {
        const i = this.nodesCount++;
        this.pos[i*2] = x; this.pos[i*2+1] = y;
        this.mass[i] = m;
        this.invMass[i] = pinned ? 0 : 1/m;
        return i;
    }

    addLink(a, b, k = 0.8) {
        this.links.push(new Link(a, b, k));
    }

    applyGlobalTransform({R, T, V}) {
        const cos = Math.cos(R), sin = Math.sin(R);
        const gx = this.gravityVector.x, gy = this.gravityVector.y;
        this.gravityVector.x = gx*cos - gy*sin;
        this.gravityVector.y = gx*sin + gy*cos;

        for (let i = 0; i < this.nodesCount; i++) {
            const x = this.pos[i*2], y = this.pos[i*2+1];
            this.pos[i*2] = (x*cos - y*sin) + T.x;
            this.pos[i*2+1] = (x*sin + y*cos) + T.y;
            this.vel[i*2] += V.x;
            this.vel[i*2+1] += V.y;
        }
        this.updateCOMState();
        this.datumCOM = {...this.comPos};
    }

    updateCOMState() {
        let tx=0, ty=0, tvx=0, tvy=0, tm=0;
        for(let i=0;i<this.nodesCount;i++){
            tx += this.pos[i*2]*this.mass[i];
            ty += this.pos[i*2+1]*this.mass[i];
            tvx += this.vel[i*2]*this.mass[i];
            tvy += this.vel[i*2+1]*this.mass[i];
            tm += this.mass[i];
        }
        this.comPos = { x: tx/tm, y: ty/tm };
        this.vCOM = { x: tvx/tm, y: tvy/tm };
    }

    computeExternalForces(h) {
        for(let i=0;i<this.nodesCount;i++){
            if(this.invMass[i]===0) continue;
            const fx = this.gravityVector.x*this.mass[i];
            const fy = this.gravityVector.y*this.mass[i];
            this.acc[i*2]+=this.gravityVector.x;
            this.acc[i*2+1]+=this.gravityVector.y;
            this.cumulativeExternalWork += (fx*this.vel[i*2] + fy*this.vel[i*2+1])*h;
        }
    }

    evaluateMaterial(h){
        let totalV = 0;
        for(let i=this.links.length-1;i>=0;i--){
            const L = this.links[i];
            const dx = this.pos[L.b*2]-this.pos[L.a*2];
            const dy = this.pos[L.b*2+1]-this.pos[L.a*2+1];
            const dist = Math.sqrt(dx*dx+dy*dy);
            const deltaL = dist-L.length;
            const U_initial = 0.5*(L.k0*(1-L.D))*deltaL*deltaL;
            const G = U_initial/L.area;
            const d_prev = L.D;

            if(G > L.G_th) L.causalState = Math.max(L.causalState,1);
            if(G > L.G_th) L.D += Math.pow((G-L.G_th)/(L.G_crit-L.G_th),3)*(h/0.1);
            if(L.D>0 && L.causalState<1) throw new Error("Causality: Damage before Stress");

            if(L.D>=1.0){ 
                L.causalState=3;
                this.executeFracture(i,U_initial,dx/dist,dy/dist);
            }else{
                totalV += U_initial;
                const impulse=(deltaL*L.k0*h)/(this.invMass[L.a]+this.invMass[L.b]);
                this.vel[L.a*2]-=dx/dist*impulse*this.invMass[L.a];
                this.vel[L.a*2+1]-=dy/dist*impulse*this.invMass[L.a];
                this.vel[L.b*2]+=dx/dist*impulse*this.invMass[L.b];
                this.vel[L.b*2+1]+=dy/dist*impulse*this.invMass[L.b];
                L.Q+=Math.max(0,U_initial-0.5*(L.k0*(1-L.D))*deltaL*deltaL);
            }
        }
        return totalV;
    }

    step(h){
        if(this.isHalted) return;
        this.computeExternalForces(h);
        const V=this.evaluateMaterial(h);
        advanceKinematic(this.pos,this.vel,this.acc,h,this.invMass);
        this.performAudit(V);
    }

    performAudit(V){
        let T_rel=0,Ug_rel=0,totalQ=0;
        this.updateCOMState();
        for(let i=0;i<this.nodesCount;i++){
            const vx=this.vel[i*2]-this.vCOM.x;
            const vy=this.vel[i*2+1]-this.vCOM.y;
            T_rel+=0.5*this.mass[i]*(vx*vx+vy*vy);
            const dx=this.pos[i*2]-this.datumCOM.x;
            const dy=this.pos[i*2+1]-this.datumCOM.y;
            Ug_rel+=this.mass[i]*(this.gravityVector.x*dx+this.gravityVector.y*dy);
        }
        this.links.forEach(L=>totalQ+=L.Q);
        const currentE=T_rel+V+Ug_rel+totalQ;
        const residual=Math.abs(currentE-(this.initialE+this.cumulativeExternalWork));
        this.maxResidual=Math.max(this.maxResidual,residual);
        if(residual>1e-4)this.isHalted=true;
    }

    executeFracture(idx,energy,nx,ny){
        this.links.splice(idx,1); // simplified recoil
    }

    getAuditString(){ return `Max Residual: ${this.maxResidual}`; }
}
