export function advanceKinematic(pos,vel,acc,h,invMass){
    for(let i=0;i<vel.length/2;i++){
        vel[i*2]+=acc[i*2]*h;
        vel[i*2+1]+=acc[i*2+1]*h;
        pos[i*2]+=vel[i*2]*h;
        pos[i*2+1]+=vel[i*2+1]*h;
        acc[i*2]=0; acc[i*2+1]=0;
    }
}
